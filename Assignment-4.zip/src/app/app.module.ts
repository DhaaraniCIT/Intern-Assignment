import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { environment } from 'src/environments/environment';
import { FormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AppService } from "./app.service";
import { AppInterceptor } from './app.interceptor';
import { HttpClientModule, HTTP_INTERCEPTORS, HttpClientJsonpModule } from '@angular/common/http';

import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { SuccessAlertComponent } from './successAlert/successAlert.component';
import { ProccessAlertComponent } from './proccess-alert/proccess-alert.component';
import { WarningAlertComponent } from './warningAlert/warningAlert.component';
import { Ass1Component } from './ass1/ass1.component';
import { Ass2Component } from './ass2/ass2.component';
import { Ass3Component } from './ass3/ass3.component';
import { GameControlComponent } from './ass4/game-control/game-control.component';
import { OddComponent } from './ass4/odd/odd.component';
import { EvenComponent } from './ass4/even/even.component';
import { Ass4Component } from './ass4/ass4.component';

@NgModule({
  declarations: [
    AppComponent,
    SuccessAlertComponent,
    ProccessAlertComponent,
    WarningAlertComponent,
    Ass1Component,
    Ass2Component,
    Ass3Component,
    Ass4Component,
    GameControlComponent,
    OddComponent,
    EvenComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    HttpClientJsonpModule,
    BrowserAnimationsModule,
    FormsModule
  ],
  providers: [
    
],
  bootstrap: [AppComponent]
})
export class AppModule { }
