import { Component} from '@angular/core'

@Component({
    selector:'app-success',
    templateUrl:'./successAlert.component.html',

})
export class SuccessAlertComponent{
    
}