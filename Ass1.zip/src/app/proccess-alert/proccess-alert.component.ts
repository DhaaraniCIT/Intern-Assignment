import { Component, OnInit } from '@angular/core';

@Component({
  selector: '[app-proccess-alert]',
  templateUrl: './proccess-alert.component.html',
  styleUrls: ['./proccess-alert.component.css']
})
export class ProccessAlertComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
