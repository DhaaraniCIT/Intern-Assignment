import { Component, EventEmitter, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-game-control',
  templateUrl: './game-control.component.html',
  styleUrls: ['./game-control.component.css']
})
export class GameControlComponent implements OnInit {

  constructor() { }
  @Output() intervelFired = new EventEmitter<number>();
  intervel;
  lastNum=0;

  ngOnInit(): void {
  }

  onStart(){
    this.intervel = setInterval(
      ()=>{
        this.intervelFired.emit(this.lastNum+1);
        this.lastNum++;
      },
      1000
    )
  }
  onPause(){
    clearInterval(this.intervel) 
  }

}
