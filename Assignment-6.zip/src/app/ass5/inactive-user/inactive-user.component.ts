import { Component, OnInit } from '@angular/core';
import { AppService } from 'src/app/app.service';

@Component({
  selector: 'app-inactive-user',
  templateUrl: './inactive-user.component.html',
  styleUrls: ['./inactive-user.component.css']
})
export class InactiveUserComponent implements OnInit {

  constructor(private service:AppService) { }
  inactiveUsers=[]
  ngOnInit(): void {
    this.inactiveUsers = this.service.inactive
  }

  toActive(i){
   this.service.changeToActive(i)
  }

}
