import { Injectable } from '@angular/core';
// import { AngularFirestore } from '@angular/fire/firestore';
// import { ApiService } from './api.service';
import { HttpClient,HttpHeaders } from '@angular/common/http';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable({
  providedIn: 'root'
})
export class AppService {

  active = ['Dhaarani','Arthi','Dhivya']
  inactive = ['Sowmya','Chitra','Keerthi']
  constructor(private api:HttpClient) { }

  // getUsers() { 
  //   return this.api.get('http://127.0.0.1:5000/getuser')
  // }
  // // getUsers1(){
  // //   var s = this.firestore.collection('user1').snapshotChanges();
  // //   console.log(s)
  // //   return s
  // // }
  // updateStatus(data){
  //   return this.api.post('http://127.0.0.1:5000/updateDisabled',data)
  // }
  changeToActive(i){
    this.active.push(this.inactive[i])
    this.inactive.splice(i,1)
  }
  changeToinActive(i){
    this.inactive.push(this.active[i])
    this.active.splice(i,1)
  }
}
