import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AppService } from "./app.service";
import { AppInterceptor } from './app.interceptor';
import { HttpClientModule, HTTP_INTERCEPTORS, HttpClientJsonpModule } from '@angular/common/http';

import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { SuccessAlertComponent } from './successAlert/successAlert.component';
import { ProccessAlertComponent } from './proccess-alert/proccess-alert.component';
import { WarningAlertComponent } from './warningAlert/warningAlert.component';
import { Ass1Component } from './ass1/ass1.component';
import { Ass2Component } from './ass2/ass2.component';
import { Ass3Component } from './ass3/ass3.component';
import { GameControlComponent } from './ass4/game-control/game-control.component';
import { OddComponent } from './ass4/odd/odd.component';
import { EvenComponent } from './ass4/even/even.component';
import { Ass4Component } from './ass4/ass4.component';
import { Ass5Component } from './ass5/ass5.component';
import { ActiveUserComponent } from './ass5/active-user/active-user.component';
import { InactiveUserComponent } from './ass5/inactive-user/inactive-user.component';
import { Ass6Component } from './ass6/ass6.component';
import { TemplateAngularFormComponent } from './ass6/template-angular-form/template-angular-form.component';
import { ReactiveAngularFormComponent } from './ass6/reactive-angular-form/reactive-angular-form.component';

@NgModule({
  declarations: [
    AppComponent,
    SuccessAlertComponent,
    ProccessAlertComponent,
    WarningAlertComponent,
    Ass1Component,
    Ass2Component,
    Ass3Component,
    Ass4Component,
    GameControlComponent,
    OddComponent,
    EvenComponent,
    Ass5Component,
    ActiveUserComponent,
    InactiveUserComponent,
    Ass6Component,
    TemplateAngularFormComponent,
    ReactiveAngularFormComponent,
   
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    HttpClientJsonpModule,
    BrowserAnimationsModule,
    FormsModule,
    ReactiveFormsModule,
  ],
  providers: [
    AppService
],
  bootstrap: [AppComponent]
})
export class AppModule { }
