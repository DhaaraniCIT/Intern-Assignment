import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Ass6Component } from './ass6.component';

describe('Ass6Component', () => {
  let component: Ass6Component;
  let fixture: ComponentFixture<Ass6Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Ass6Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Ass6Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
