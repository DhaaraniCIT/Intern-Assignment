import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ass6',
  templateUrl: './ass6.component.html',
  styleUrls: ['./ass6.component.css']
})
export class Ass6Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
