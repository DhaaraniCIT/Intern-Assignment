import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-template-angular-form',
  templateUrl: './template-angular-form.component.html',
  styleUrls: ['./template-angular-form.component.css']
})
export class TemplateAngularFormComponent implements OnInit {

  constructor() { }

  sub='basic'
  emailvalue=''
  passwordvalue=''
  data;
  submitted=false
  ngOnInit(): void {
  }

  onSubmit(form){
    this.submitted=true
    this.data={
      email:form.value.email,
      password:form.value.password,
      sub:form.value.subs
    }
    form.reset()
    this.sub='basic'
    
  }
}
