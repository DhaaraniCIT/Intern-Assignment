import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { Ass1Component } from './ass1/ass1.component';
import { Ass2Component } from './ass2/ass2.component';
import { Ass3Component } from './ass3/ass3.component';
import { Ass4Component } from './ass4/ass4.component';
import { Ass5Component } from './ass5/ass5.component';
import { Ass6Component } from './ass6/ass6.component';

const routes: Routes = [
  {path:'',component:Ass1Component},
  {path:'ass2',component:Ass2Component},
  {path:'ass3',component:Ass3Component},
  {path:'ass4',component:Ass4Component},
  {path:'ass5',component:Ass5Component},
  {path:'ass6',component:Ass6Component},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
