import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators} from '@angular/forms';

@Component({
  selector: 'app-reactive-angular-form',
  templateUrl: './reactive-angular-form.component.html',
  styleUrls: ['./reactive-angular-form.component.css']
})
export class ReactiveAngularFormComponent implements OnInit {
  registerForm: FormGroup;
  data;
  submitted=false
  constructor(private formBuilder:FormBuilder) { }

  ngOnInit(): void {
    this.registerForm = this.formBuilder.group({
      projectname:['',[Validators.required, Validators.pattern('[A-Za-z]*')]],
      email:['',[Validators.required, Validators.pattern('^([a-zA-Z0-9]+)([\_\.\-{1}])?([a-zA-Z0-9]+)\@([a-zA-Z0-9]+)([\.\_\-])([a-zA-Z\.]+)$')]],
      status:['stable',[Validators.required]]
    })
  }

  get f() {return this.registerForm.controls;}

  register(){
    this.data={
      projectName:this.f.projectname.value,
      email:this.f.email.value,
      status:this.f.status.value,
    }
    this.registerForm.reset()
    this.f.status.patchValue('stable')
  }
}
