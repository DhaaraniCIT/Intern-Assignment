import { Component, OnInit } from '@angular/core';
import { count } from 'rxjs/operators';

@Component({
  selector: 'app-ass3',
  templateUrl: './ass3.component.html',
  styleUrls: ['./ass3.component.css']
})
export class Ass3Component implements OnInit {

  constructor() { }

  countArr=[]
  count=0
  isClicked = true

  ngOnInit(): void {
  }

  clicked(){
    this.countArr.push(this.count++)
    this.isClicked=!this.isClicked
  }
}
