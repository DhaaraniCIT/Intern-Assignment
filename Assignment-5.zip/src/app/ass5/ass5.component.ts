import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ass5',
  templateUrl: './ass5.component.html',
  styleUrls: ['./ass5.component.css']
})
export class Ass5Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
