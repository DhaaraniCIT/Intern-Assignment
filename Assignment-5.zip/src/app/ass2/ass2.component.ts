import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-ass2',
  templateUrl: './ass2.component.html',
  styleUrls: ['./ass2.component.css']
})
export class Ass2Component implements OnInit {

  constructor() { }

  userName:any
  isEnabled=false

  ngOnInit(): void {
    setTimeout(()=>{                          
      this.isEnabled = true;
 }, 3000);
  }

  onClick(){
    console.log(this.userName)
    this.userName=''
  }
}
