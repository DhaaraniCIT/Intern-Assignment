import { Component } from '@angular/core'

@Component({
    selector:'.app-warning',
    template:'<app-success></app-success>',
    // styleUrls:['./warning.component.css']
    styles: ['h1 { color:red; }']
})

export class WarningAlertComponent{}