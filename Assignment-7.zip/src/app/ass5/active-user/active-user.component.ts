import { Component, OnInit } from '@angular/core';
import { AppService } from '../../app.service'
@Component({
  selector: 'app-active-user',
  templateUrl: './active-user.component.html',
  styleUrls: ['./active-user.component.css']
})
export class ActiveUserComponent implements OnInit {

  constructor(private service:AppService) { }
  activeUsers=[]
  ngOnInit(): void {
    this.activeUsers = this.service.active
    console.log(this.activeUsers)
  }

  toInactive(i){
   this.service.changeToinActive(i)
  }
}
