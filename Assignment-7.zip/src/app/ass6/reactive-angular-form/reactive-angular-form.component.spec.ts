import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReactiveAngularFormComponent } from './reactive-angular-form.component';

describe('ReactiveAngularFormComponent', () => {
  let component: ReactiveAngularFormComponent;
  let fixture: ComponentFixture<ReactiveAngularFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReactiveAngularFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReactiveAngularFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
