import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TemplateAngularFormComponent } from './template-angular-form.component';

describe('TemplateAngularFormComponent', () => {
  let component: TemplateAngularFormComponent;
  let fixture: ComponentFixture<TemplateAngularFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TemplateAngularFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TemplateAngularFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
