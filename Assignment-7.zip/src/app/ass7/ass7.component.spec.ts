import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Ass7Component } from './ass7.component';

describe('Ass7Component', () => {
  let component: Ass7Component;
  let fixture: ComponentFixture<Ass7Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Ass7Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Ass7Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
