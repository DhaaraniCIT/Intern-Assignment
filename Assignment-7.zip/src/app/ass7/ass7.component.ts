import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ass7',
  templateUrl: './ass7.component.html',
  styleUrls: ['./ass7.component.css']
})
export class Ass7Component implements OnInit {

  constructor() { }
  server=[
    {
      firstName:"Dhaarani Selvam",
      lastName:"Selvam",
      DOB:new Date()
    },
    {
      firstName:"Chitra Selvam",
      lastName:"Selvam",
      DOB:new Date()
    },
    {
      firstName:"Sowmya Senthil",
      lastName:"Senthil",
      DOB:new Date()
    },
    {
      firstName:"Arthi Durai",
      lastName:"Durai",
      DOB:new Date()
    },
    {
      firstName:"Keerthi Suresh",
      lastName:"Suresh",
      DOB:new Date()
    },
  ]
  ngOnInit(): void {
  }

}
