import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ass4',
  templateUrl: './ass4.component.html',
//   styleUrls: ['./odd.component.css']
})
export class Ass4Component implements OnInit {

  constructor() { }

    odd = []
    even = []

  ngOnInit(): void {
  }

  onintervelFired(num:number){
    console.log(num)
    if(num%2 == 0){
        this.even.push(num)
    }
    else{
        this.odd.push(num)
    }
  }

}
