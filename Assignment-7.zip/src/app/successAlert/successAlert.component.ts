import { Component} from '@angular/core'

@Component({
    selector:'app-success',
    template:`<div class="container">
                    <div class="">
                    <h1>Dhaarani. S</h1>
                    <h3>M. Sc. Software Systems, Final year</h3>
                    <h3>Inten at Faclon Labs</h3>
                </div>
            </div>
        `,
    styles:[`
        h1{color:red;font-family: "Montserrat", sans-serif;}
        h3{color:blue}
    `]

})
export class SuccessAlertComponent{
    
}