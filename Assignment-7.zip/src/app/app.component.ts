import { Component } from '@angular/core';
// import { AngularFireDatabase,AngularFireList } from 'angularfire2/database';
// import { Observable } from 'rxjs';
// import { AngularFirestore } from '@angular/fire/firestore';
import { AppService } from './app.service'
declare var $: any;
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
  // styles:['h3 {color:blue;font-family: "Montserrat", sans-serif;}']
})
export class AppComponent {}
